import React from 'react'
import workInProgress from "../assets/workInProgress.jpg"
const AboutUsPage = () => {
  return (
   <img src={workInProgress} className="w-[500px] relative left-[500px] top-[100px]" alt="" srcset="" />
  )
}

export default AboutUsPage
import React from 'react'

const LoginButton = () => {
    console.log("hello")
  return (
    <div>
        hello
    </div>
  )
}

export default LoginButton